<?php
// Check if the request is a POST request
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Retrieve the JSON data sent from the client
    $postData = file_get_contents("php://input");

    // Attempt to decode the JSON data into a PHP associative array
    $recipeData = json_decode($postData, true);

    // Check if decoding was successful and data is valid
    if ($recipeData && is_array($recipeData)) {
        // Example: Perform additional validation or database operations
        // Here, you can implement your logic to save the recipe data to a database or perform other actions
        
        // For demonstration, you can simply output the received data as a response
        $response = [
            'status' => 'success',
            'message' => 'Recipe submitted successfully',
            'data' => $recipeData // Sending back the received data as confirmation
        ];

        // Send JSON response back to the client
        header('Content-Type: application/json');
        echo json_encode($response);
    } else {
        // Handle invalid or missing data
        http_response_code(400); // Bad request
        echo json_encode(['status' => 'error', 'message' => 'Invalid or missing data']);
    }
} else {
    // Handle invalid request method
    http_response_code(405); // Method Not Allowed
    echo json_encode(['status' => 'error', 'message' => 'Method Not Allowed']);
}
?>
