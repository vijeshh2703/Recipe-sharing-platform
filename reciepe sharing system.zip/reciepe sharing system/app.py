from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

# Landing page redirects to login
@app.route('/')
def index():
    return redirect(url_for('login'))

# Login page
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        # Dummy authentication logic (replace with actual logic)
        username = request.form['username']
        password = request.form['password']
        
        # Check username and password (for demo purposes)
        if username == 'demo' and password == 'demo':
            return redirect(url_for('index'))  # Redirect to home (index) page
        else:
            return render_template('index.html')  # Render login page again if authentication fails

    return render_template('login.html')  # Render login page for GET requests

# Home page after login (corresponds to index)
@app.route('/home')
def home():
    return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True)

